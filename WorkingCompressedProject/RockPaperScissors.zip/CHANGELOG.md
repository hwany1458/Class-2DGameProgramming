# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [0.0.1] - 2017-11-01

### Added *Unity Package \com.unity.2dtemplate*.

-Project Setting updated for 2D

## [0.0.2] - 2017-12-05

### Updating *Unity Package \com.unity.template.2d*.

-changing folder structure, adding default scene

## [0.0.3] - 2017-12-15

### Updating *Unity Package \com.unity.template.2d*.

-changing quality settings to be appropriate for 2D games.

## [0.0.4] - 2018-1-26

### Updating *Unity Package \com.unity.template.2d*.

-removing text object.