# Quality Report
Use this file to outline the test strategy for this package.

## QA Owner: Kevin Maxon
## UX Owner: [*Add Name*]

## Test strategy
*Use this section to describe how this feature was tested.*
* A link to the Test Plan https://docs.google.com/document/d/1siefCNL9zatiyUWFxqzyrJNov9Bs0xNov0T4s1oJycU/edit


## Package Status
Use this section to describe:
* UX status/evaluation results
* package stability
* known bugs, issues
* performance metrics,
* etc

* TODOS - this scene should still have some example content appropiate for 2D in the samplescene.unity file
*		- this scene should have camera script for 2D WASD controls
* Questions - Do we want to use Lightweight SRP?

