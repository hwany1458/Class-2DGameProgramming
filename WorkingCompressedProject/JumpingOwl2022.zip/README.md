# upm-package-template-3DLegacy
Project Template for 3D scenes not using a SRP and empty

This template uses Unity’s built in rendering pipeline and contain no content by default. This is a good starting point for developers looking to create 3D projects.


Package Name: com.unity.template.3dempty
Package Version: 0.0.2