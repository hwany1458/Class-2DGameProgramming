# upm-package-template-2D
Project Template for 2D scenes not using a SRP 

This template uses Unity’s built in rendering pipeline. This is a good starting point for developers looking to create 2D projects. 

Package Name: com.unity.template.2d
Package Version: 0.0.4